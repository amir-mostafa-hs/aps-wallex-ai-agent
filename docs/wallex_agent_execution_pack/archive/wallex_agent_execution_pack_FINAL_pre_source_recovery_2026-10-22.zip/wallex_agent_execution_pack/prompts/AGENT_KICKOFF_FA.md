# Prompt شروع پروژه برای Coding Agent

تو Lead Engineer پروژه Wallex Opportunity Agent هستی. هدف، ساخت نسخه مسابقه در کمتر از ۴۸ ساعت است. ابتدا `README_FA.md`, `AGENTS.md`, `source_materials/README_FA.md` و تمام فایل‌های `docs/DECISION_REGISTER_FA.md`, `docs/SOURCE_MATERIALS_AND_GAPS_FA.md`, `docs/SPEC_FA.md`, `docs/AGENT_CONTRACT_FA.md`, `docs/ARCHITECTURE_FA.md`, `docs/MARKET_SCANNING_DECISION_LOGIC_FA.md`, `docs/TODO_48H_FA.md`, `docs/TESTING_REPORTING_FA.md`, `docs/CODING_AGENT_WORKFLOW_FA.md`, `docs/WALLEX_API_NOTES.md`, `docs/RELATED_OPEN_SOURCE_REFERENCES_FA.md`, `docs/CHANGELOG_AUDIT_FA.md` و `reports/FINAL_REPORT_TEMPLATE.md` را بخوان.

## تصمیم معماری الزامی: LangChain

از LangChain به‌عنوان لایه تصمیم‌گیری Agent استفاده کن. در نسخه اول یک Decision Agent با `create_agent` و خروجی ساختاریافته با کلاس `TypedDict` مسیر پیش‌فرض است؛ اگر JSON Schema خام استفاده شد، آن را طبق نسخه نصب‌شده در `ProviderStrategy` یا `ToolStrategy` مناسب قرار بده؛ قرارداد مرکزی `docs/AGENT_CONTRACT_FA.md` را دقیقاً اجرا کن و schema موازی نساز. در کد دامنه مدل Pydantic تعریف/استفاده مستقیم نکن مگر اینکه blocker فنی مستند و با کاربر توافق شده باشد. وابستگی غیرمستقیم packageها را بدون بررسی حذف نکن. اگر provider از OpenAI-compatible API پشتیبانی می‌کند integration سازگار مناسب را به‌کار ببر؛ در غیر این صورت package رسمی provider را انتخاب کن. API دقیق را با نسخه نصب‌شده بررسی کن و dependencyها را lock کن. scheduler، scanner، feature-engine، Portfolio/Risk Engine و Order Executor را کد قطعی و تست‌پذیر نگه دار. ابزارهای LangChain فقط read-only/context tools باشند؛ به مدل امکان مستقیم ثبت/لغو سفارش نده. swarm یا graph پیچیده نساز مگر دلیل فنی مستند وجود داشته باشد.

## قوانین غیرقابل‌مذاکره

1. هیچ endpoint، param، auth header یا response shape والکس را حدس نزن. مستند فعلی `https://developers.wallex.ir/docs` را بخوان و نتیجه را در `docs/WALLEX_API_NOTES.md` ثبت کن. اول read-only Spike.
2. API Keyها را فقط از environment بخوان؛ هرگز چاپ، commit یا در database/log ذخیره نکن.
3. `assets.md` باید منبع denylist نمادهای ممنوع/غیرفعال باشد. ابتدا فهرست دقیق را استخراج کن و با فعال‌بودن API و Spot capability تطبیق بده. اگر فایل موجود نیست یا قابل‌خواندن نیست، live trading را block کن و علامت واضح بده.
4. رفتار پیش‌فرض `MODE=shadow` است. Live باید علاوه بر `MODE=live` به `LIVE_TRADING_ENABLED=true`, `LIVE_PREFLIGHT_ACKNOWLEDGED=true` و preflight pass نیاز داشته باشد؛ این gate برای راه‌اندازی یک‌باره است و پس از آن سفارش‌ها خودکارند.
5. AI فقط TradeIntent ساختاریافته تولید می‌کند؛ Risk Engine و Order Executor جدا هستند. هیچ direct call از مدل به private trading endpoint مجاز نیست.
6. در timeout سفارش، ابتدا reconcile با client ID/order detail؛ retry کور ممنوع.
7. جلوگیری از duplicate order، self-trade و Wash Trading الزامی است.
8. هر تصمیم، reject، سفارش، fill، fee، P&L و خطا در DB ثبت شود.
9. سود واقعی را با P&L تحقق‌یافته net از کارمزد محاسبه کن؛ نتایج Backtest/Shadow را جدا نگه دار.
10. فقط task جاری را پیاده‌سازی کن، تست اجرا کن و diff را مرور کن. اگر blocker یا تناقض با Spec دیدی، آن را آشکار گزارش بده؛ پنهانی حدس نزن.

## دستور کار اول

قبل از نوشتن موتور استراتژی:

- وضعیت repo و فایل‌ها را بررسی کن.
- endpointهای رسمی market list، market data/candles, balance, open orders, order create, order detail, cancel و recent trades را در صورت وجود پیدا کن.
- تست read-only با نمونه responseهای sanitized اضافه کن.
- دسترسی API Key به حساب اعتباری را اثبات کن.
- داده تاریخی موجود و rate limits را بررسی کن.
- مدل داده نمودار را تأیید کن: OHLCV candle، نه تصویر. endpoint history را در docs فعلی verify کن؛ اگر تایم‌فریم ۵m/۱۵m مستقیم پشتیبانی نشد، از کندل ۱m محلی resample کن.
- cadence پیشنهادی اولیه را در config پیاده کن (universe ~900s، summary ~30s، scan 15s، AI min interval 30s و cap 3 call/min به‌طور هم‌زمان، order reconciliation ~5s فقط اگر rate-limit اجازه داد). عمر داده Candidate و عمر quote قبل از submit را جدا کن (baseline: 45s و 5s) و همه را با rate-limit/latency واقعی اندازه‌گیری کن.
- در نهایت یک گزارش کوتاه با endpointهای تأییدشده، عدم‌قطعیت‌ها و پیشنهاد vertical slice بعدی بده. فایل‌های اصلی `assets.md`, `intro-text.md`, `task.md` و PDF باید پیش از Live حاضر و بررسی شده باشند؛ اگر denylist واقعی از `assets.md` در repo نیست، Live را block کن.

## پس از Spike

به ترتیب `docs/TODO_48H_FA.md` پیش برو. ابتدا یک مسیر end-to-end کوچک در Shadow بساز. بعد Backtest، تست خطاها، dashboard، live preflight و اجرای واقعی محدود را اضافه کن. ویژگی‌های خارج از دامنه را قبل از تکمیل P0/P1 نساز.

## معیار نهایی

در پایان ۴۸ ساعت باید سیستم بتواند در VPS اجرا شود، بازارهای مجاز را اسکن کند، در هر بازار Candidate بسازد، AI واقعاً از میان استراتژی/افق‌های مجاز انتخاب کند، Risk Engine معامله ناامن را رد کند، سفارش واقعی را با reconciliation امن اجرا کند، معاملات و ضررها را برای تحلیل ذخیره کند، Backtest و Shadow results بدهد و گزارش از DB مجدداً قابل تولید باشد.
