# گزارش بازبینی جامع و تغییرات بسته

نسخه: 1.1-final-audit · تاریخ بازبینی: 2026-10-22

## 1. فایل‌های موجود حفظ‌شده

فایل‌های زیر از بسته قبلی حذف نشده‌اند؛ متن آن‌ها بازبینی/هم‌تراز شده یا به‌صورت محتوای قبلی حفظ شده است:

- `README_FA.md`
- `AGENTS.md`
- `.env.example`
- `docs/SPEC_FA.md`
- `docs/ARCHITECTURE_FA.md`
- `docs/MARKET_SCANNING_DECISION_LOGIC_FA.md`
- `docs/TODO_48H_FA.md`
- `docs/TESTING_REPORTING_FA.md`
- `docs/CODING_AGENT_WORKFLOW_FA.md`
- `docs/WALLEX_API_NOTES.md`
- `prompts/AGENT_KICKOFF_FA.md`
- `reports/FINAL_REPORT_TEMPLATE.md`

فایل‌های زیر به بسته اضافه شدند تا تصمیم‌های همین گفت‌وگو بین README، Spec، prompt و Agent دوپهلو نشوند:

- `docs/AGENT_CONTRACT_FA.md` — منبع واحد actionها، افق نگهداری، schema و validation.
- `docs/DECISION_REGISTER_FA.md` — تصمیم‌های Grill-me، جدول امتیازدهی و موارد کاربر.
- `docs/SOURCE_MATERIALS_AND_GAPS_FA.md` — فایل‌های منبع و شکاف‌های تأییدنشده.
- `docs/RELATED_OPEN_SOURCE_REFERENCES_FA.md` — پروژه‌های متن‌باز، LangChain و Matt Pocock Skills.
- `docs/CHANGELOG_AUDIT_FA.md` — همین گزارش.
- `docs/GRILL_ME_HISTORY_FA.md` — تاریخچه تصمیم‌ها و گزینه‌های Grill-me به ترتیب.
- `docs/PACKAGE_AUDIT_FA.md` — دامنه بازبینی نهایی و محدودیت‌های تحویل.
- `source_materials/README_FA.md` — فهرست ضمیمه‌های اصلی لازم و هشدار درباره نبود فایل خام در این بازسازی.

## 2. تناقض‌هایی که هم‌تراز شدند

- خروجی Agent: همه مستندات باید از `NO_TRADE`, `BUY`, `HOLD`, `EXIT` استفاده کنند؛ قرارداد معنایی در `AGENT_CONTRACT_FA.md`.
- Candle timeframe با holding horizon جدا شد: تایم‌فریم‌های داده `1m/5m/15m/1h` و افق نگهداری `FAST/INTRADAY_SHORT/INTRADAY`.
- LangChain در نقش orchestration Agent باقی است؛ Pydantic models از کد دامنه حذف/الزام‌زدایی شده‌اند و TypedDict/JSON Schema همراه Validator مستقل تعریف شده‌اند. dependency ترانزیتی ممکن است باقی بماند.
- cadenceهای scan، summary، AI و order reconciliation از هم تفکیک شدند؛ مقادیر به‌عنوان baseline و نه قانون Wallex برچسب خوردند.
- تازگی Candidate با تازگی quote قبل از submit جدا شد؛ cached snapshot به‌تنهایی مجوز اجرای سفارش نیست.
- «فعال بودن الگوریتم» به معنی معامله به هر قیمت نیست؛ مزیت خالص پس از fee/spread/slippage و ریسک باید برقرار باشد.
- realized P&L برای گزارش سود با equity/drawdown جدا شد؛ سود تحقق‌نیافته به‌عنوان سود تحقق‌یافته معرفی نشود.
- در حساب اعتباری هکاتون، دامنه همچنان Spot بدون لوریج است؛ عنوان اعتبار به معنی مجاز بودن Margin/Short فرض نمی‌شود.
- سفارش timeout، partial fill، restart، duplicate و self-trade/wash safeguards در معیارهای P0 باقی ماندند.

## 3. چک‌لیست یکپارچگی

- [ ] تمام action/horizon fields در code و test فقط از `AGENT_CONTRACT_FA.md` مشتق شوند.
- [ ] هیچ direct trade tool به LangChain Agent داده نشود.
- [ ] Live در نبود denylist اصلی و API preflight fail closed کند.
- [ ] endpointهایی که هنوز تست و شاهد ندارند، `Confirmed` معرفی نشوند.
- [ ] نرخ‌های اولیه قبل از استفاده با rate limit و latency اندازه‌گیری شوند.
- [ ] ریسک‌های پیشنهادی `.env.example` با قوانین رسمی اشتباه نشوند؛ مرور و ثبت config لازم است.
- [ ] Backtest/Shadow/Live به‌طور جداگانه علامت‌گذاری شوند و گزارش از DB قابل بازتولید باشد.
- [ ] فایل zip پس از ساخت test شود و شامل همه فایل‌های ثبت‌شده در manifest باشد.

## 4. محدودیت بازسازی منبع

در بازسازی فعلی، محتوای خام چهار ضمیمه اولیه از مسیر فایل‌خوان/مادیالایز قابل دریافت نبود؛ بنابراین این ZIP ادعا نمی‌کند متن کامل یا نمادهای `assets.md` را بازتولید کرده است. برداشت‌های قابل‌اتکا از گفت‌وگو در `DECISION_REGISTER_FA.md` ثبت شده‌اند. قبل از Live باید اصل فایل‌های `assets.md`, `intro-text.md`, `task.md` و PDF در repo حاضر و مرور شوند. این شکاف نباید با داده یا نماد ساختگی پر شود.

